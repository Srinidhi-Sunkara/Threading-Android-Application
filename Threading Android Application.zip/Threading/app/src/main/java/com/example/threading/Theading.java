package com.example.threading;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class Theading extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_theading);
    }
}
